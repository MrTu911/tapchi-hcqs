
import { BannerForm } from '@/components/dashboard/banner-form';

export default function NewBannerPage() {
  return <BannerForm />;
}
