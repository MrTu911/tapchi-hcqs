import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getServerSession } from '@/lib/auth';
import { logAudit, AuditEventType } from '@/lib/audit-logger';
import { Role } from '@prisma/client';

// GET - Lấy danh sách yêu cầu nâng quyền
export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Chỉ SYSADMIN và EIC được xem
    if (!['SYSADMIN', 'EIC'].includes(session.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');

    const requests = await prisma.roleEscalationRequest.findMany({
      where: status ? { status: status as any } : undefined,
      include: {
        user: {
          select: {
            id: true,
            fullName: true,
            email: true,
            role: true,
            org: true,
          },
        },
        requester: {
          select: {
            fullName: true,
            email: true,
          },
        },
        approver: {
          select: {
            fullName: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json({
      success: true,
      data: requests,
    });
  } catch (error: any) {
    console.error('Error fetching role escalation requests:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    );
  }
}

// POST - Tạo yêu cầu nâng quyền mới
export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { requestedRole, reason } = body;

    // Validate
    if (!requestedRole || !reason) {
      return NextResponse.json(
        { error: 'Thiếu thông tin bắt buộc' },
        { status: 400 }
      );
    }

    // Kiểm tra xem đã có yêu cầu PENDING chưa
    const existingRequest = await prisma.roleEscalationRequest.findFirst({
      where: {
        userId: session.uid,
        status: 'PENDING',
      },
    });

    if (existingRequest) {
      return NextResponse.json(
        { error: 'Bạn đã có yêu cầu đang chờ duyệt' },
        { status: 400 }
      );
    }

    // Tạo yêu cầu mới
    const request = await prisma.roleEscalationRequest.create({
      data: {
        userId: session.uid,
        currentRole: session.role as Role,
        requestedRole: requestedRole as Role,
        reason,
        requestedBy: session.uid,
      },
      include: {
        user: {
          select: {
            fullName: true,
            email: true,
          },
        },
      },
    });

    // Log audit
    await logAudit({
      actorId: session.uid,
      action: AuditEventType.ROLE_ESCALATION_REQUESTED,
      object: `ROLE_ESCALATION:${request.id}`,
      after: { requestedRole, reason },
    });

    return NextResponse.json({
      success: true,
      data: request,
      message: 'Yêu cầu nâng quyền đã được gửi',
    });
  } catch (error: any) {
    console.error('Error creating role escalation request:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    );
  }
}

// PATCH - Duyệt hoặc từ chối yêu cầu
export async function PATCH(req: NextRequest) {
  try {
    const session = await getServerSession();
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Chỉ SYSADMIN và EIC được duyệt
    if (!['SYSADMIN', 'EIC'].includes(session.role)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    const body = await req.json();
    const { id, status, rejectionReason } = body;

    if (!id || !status) {
      return NextResponse.json(
        { error: 'Thiếu thông tin bắt buộc' },
        { status: 400 }
      );
    }

    // Kiểm tra request tồn tại
    const request = await prisma.roleEscalationRequest.findUnique({
      where: { id },
      include: { user: true },
    });

    if (!request) {
      return NextResponse.json(
        { error: 'Không tìm thấy yêu cầu' },
        { status: 404 }
      );
    }

    if (request.status !== 'PENDING') {
      return NextResponse.json(
        { error: 'Yêu cầu này đã được xử lý' },
        { status: 400 }
      );
    }

    // Cập nhật request
    const updateData: any = {
      status,
      approvedBy: session.uid,
    };

    if (status === 'APPROVED') {
      updateData.approvedAt = new Date();
      // Cập nhật role của user
      await prisma.user.update({
        where: { id: request.userId },
        data: { role: request.requestedRole },
      });
    } else if (status === 'REJECTED') {
      updateData.rejectedAt = new Date();
      updateData.rejectionReason = rejectionReason || 'Không được phê duyệt';
    }

    const updatedRequest = await prisma.roleEscalationRequest.update({
      where: { id },
      data: updateData,
      include: {
        user: true,
        approver: true,
      },
    });

    // Log audit
    await logAudit({
      actorId: session.uid,
      action:
        status === 'APPROVED'
          ? AuditEventType.ROLE_ESCALATION_APPROVED
          : AuditEventType.ROLE_ESCALATION_REJECTED,
      object: `ROLE_ESCALATION:${id}`,
      before: { status: request.status },
      after: { status, rejectionReason },
    });

    return NextResponse.json({
      success: true,
      data: updatedRequest,
      message:
        status === 'APPROVED'
          ? 'Yêu cầu đã được phê duyệt'
          : 'Yêu cầu đã bị từ chối',
    });
  } catch (error: any) {
    console.error('Error updating role escalation request:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    );
  }
}
